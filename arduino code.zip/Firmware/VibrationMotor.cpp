#include <Arduino.h>
#include "VibrationMotor.h"

VibrationMotor::VibrationMotor(const int pin) : Switchable(pin)
{
	
}
