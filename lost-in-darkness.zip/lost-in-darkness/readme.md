### COMP140 Game: Lost In Darkness ### 

Link to repository:
https://gamesgit.falmouth.ac.uk/users/lr228874/repos/lost-in-darkness/browse 

Player movement from:
https://docs.unity3d.com/ScriptReference/Input.GetAxis.html

On the master branch the game works with keyboard controls.
On the arduino branch the game works with the arduino controller. 

