﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class WinLine : MonoBehaviour
{
    private Scene currentScene;     //stores the name of the current scene
    private int currentLevel = 0;       //stores the value of the current scene
    private string lastLevel = "Level_2";       //stores the name of the last scene

    //load next scene in build order
    private void Collision()
    {
        currentScene = SceneManager.GetActiveScene();       //gets the name of the current scene
        if (currentScene.name == lastLevel)      //checks to see if the player is on the last level
        {
            Debug.Log("You Win");
        }
        else        //loads the next level if the player is not the last level
        { 
            SceneManager.LoadScene(currentLevel + 1);      
        }
    }

    //actives on collsion
    private void OnCollisionEnter2D(Collision2D coll)
    {
        Collision();
    }
}
