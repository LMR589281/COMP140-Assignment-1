﻿using UnityEngine;

public class MovingPlatform : Wall      //this class is a child of the wall class
{
    private float moveSpeed = 5;       //movement speed of the platform
    [SerializeField] private float maxHight = 15;      //maximum high of the platfrom
    [SerializeField] private float minHight = -9;      //minimum high of the platfrom
    private bool movingUp = true;

    //moves platfrom based on its current postion
    private void Moving(float move_speed)
    {
        if (movingUp == true)      //checks to see what way the platform is moving
        {
            transform.position = new Vector2(transform.position.x, transform.position.y + move_speed * Time.deltaTime);     //moves the platform up
            if (maxHight <= transform.position.y)       //checks to see if the platfrom has reached the maximum hight
            {
                movingUp = false;
            }
        }
        else
        {
            transform.position = new Vector2(transform.position.x, transform.position.y - move_speed * Time.deltaTime);     //moves the platform down
            if (minHight >= transform.position.y)       //checks to see if the platfrom has reached the minium hight
            {
                movingUp = true;
            }
        }

    }

    //updates every frame
    private void Update()
    {
        Moving(moveSpeed);
    }

    //actives on collision
    private void OnCollisionEnter2D(Collision2D coll)
    {
        DetectDamage();
        PushAway();
    }
}