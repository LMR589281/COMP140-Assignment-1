﻿/*refrences: 
https://answers.unity.com/questions/442652/removing-velocity-from-objects.html for setting player velocity to 0.
*/
using UnityEngine;
using System.IO.Ports;
using System;
using System.Collections;

public class Arduino : MonoBehaviour
{
    [SerializeField]private bool controllerActive = false;
    private int commPort = 5;        //port of the arduino
    private SerialPort serial = null;
    private bool connected = false;

    private string[] currentValues;    //values from the arduino controller 
    private string[] previousValues;       //first set of values from the arduino controller  
    private bool running = true;        //checks to see if the script has got feedback from the controller
    private float zRotation;        //used to change the rotation of the player
    [SerializeField] private GameObject wave;       //refrence to player wave sprite
    private bool echolocating = false;          //checks to see if the player is using echolocation
    private bool moving = false;        //checks to see if the player is moving
    public bool movingState = false;       //stores players current mode
    private int health = 5;     //health of the player
    private SpriteRenderer playerSprite;       //refrence to player's current sprite
    [SerializeField] private Sprite[] sprites;      //refrence to player's other sprites
    private Rigidbody2D rigidBody;      //refrence to player's rigidbody
    private int moveForce = 10;        //amount of force when moving
    private float delayTime; 

    //The start function connects to the arduino and sets the player spirte and rigidbody up for later use
    private void Start()
    {
        ConnectToSerial();
        playerSprite = GetComponent<SpriteRenderer>();
        rigidBody = GetComponent<Rigidbody2D>();
    }


    //Update is called every frame and is used to get feedback from the arduino
    private void Update()
    {
        if (controllerActive)               //checks to see if the arduino is in use
        {
            WriteToArduino("D");                     //ask the arduino for the values of the controller        
            String value = ReadFromArduino(50);     //read the positions

            if (value != null)                  //check to see if we got a responce
            {
                currentValues = value.Split('-');     //split up the 3 values

                if (currentValues.Length == 3)     //checks all 3 values where recived
                {
                    if (running)        //gets the first value of the arduino controller to detect changees in the buttons
                    {
                        previousValues = currentValues;
                        running = false;        //sets running to false so first values are not recived again
                    }
                    Debug.Log("potentiometer value:" + currentValues[0]);
                    Debug.Log("button value:" + currentValues[1]);
                    Debug.Log("switch value:" + currentValues[2]);
                    //Debug.Log(currentValues);
                    PressedButton();    //checks to see if the button has been pressed
                    PressedSwitch();    //checks to see if the switch has been pressed
                    PlayerRotation();    //updates player rotation with movement from the potentiometer
                }
            }
        }
    }

    //checks to see if the button has been pressed, then checks the player's currnet state 
    //depending on the player state it will move the player or fire and echolocation wave
    private void PressedButton()
    {
        if (currentValues[1] != previousValues[1])        //checks if button values has changed
        {
            if (previousValues[1] == "0")      //updates last button values
            {
                previousValues[1] = "1";
            }
            else
            {
                previousValues[1] = "0";
            }

            if (movingState == true && !moving)        //moves the player if they are in movement mode and not on the cool down
            {
                StartCoroutine(MovingCoolDown());       //move player forward
            }
            else
            {
                if (!echolocating)      //checks to make sure the player is not in a echolocation cool down
                {
                    Vector3 rotation = transform.rotation.eulerAngles;      //gets rotation of the player
                    //uses simple trigonometry to find the direction the player is looking in 
                    Vector2 rotation2D = new Vector2(Mathf.Cos((rotation[2] * Mathf.PI / 180)), Mathf.Sin(rotation[2] * Mathf.PI / 180));       
                    RaycastHit2D hit = Physics2D.Raycast(transform.position, rotation2D);       //simulates the using a raycast echolocation wave
                    if (hit.collider != null)
                    {
                        Debug.DrawLine(transform.position, hit.point, Color.red, 5);       //code to see echolcation in scene view
                        EcholocationFeedback(hit.distance);     //gives the distance of the wave into the feedback function
                    }
                    StartCoroutine(EcholocationCoolDown());     //starts echolocation cool down
                }
            }
        }
    }

    //checks to see if the switch has been pressed, then changes the player's currnet state 
    private void PressedSwitch()
    {
        if (currentValues[2] != previousValues[2])        //checks if button values has changed
        {
            if (previousValues[2] == "0")      //updates last button values
            {
                previousValues[2] = "1";
            }
            else
            {
                previousValues[2] = "0";
            }
            ChangeState();      //changes player state
        }
    }

    //rotates player based on potentiometer input
    private void PlayerRotation()
    {
        zRotation = float.Parse(currentValues[0]);     //changes potentiometer input into a int
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, zRotation));        //changes player rotation
    }

    //turns on virbation motor based on the distance of the wave
    private void EcholocationFeedback(float distance)
    {
        if (distance >= 50)     //wave went far 
        {
            Debug.Log("far away");
            WriteToArduino("1");        //sets of a half a second vibration
        }
        else if (distance < 50 && distance >= 25)       //wave is near
        {
            Debug.Log("near");
            WriteToArduino("2");        //sets of a 1 second vibration
        }
        else if (distance < 25 && distance >= 10)       //wave is close
        {
            Debug.Log("close");
            WriteToArduino("3");        //sets of a 1 and a half second vibration
        }
        else        //wave is very close
        {
            Debug.Log("very close");
            WriteToArduino("4");        //sets of a 2 second vibration
        }
    }

    //lowers the player's health when damaged
    public void Damage()
    {
        health -= 1;
        if (health <= 0)     //checks to see if the player is dead
        {
            Death();
        }
    }

    //disablesa player is they are dead
    private void Death() 
    {
        gameObject.SetActive(false);
    }

    //changes player's current state
    public void ChangeState()
    {
        if (movingState)       //if the player is in movement mode they change to echolocation mode
        {
            playerSprite.sprite = sprites[1];    
            movingState = false;
        }
        else        //else the player is in echolocation mode they change to movement mode
        {
            playerSprite.sprite = sprites[0];
            movingState = true;
        }
    }

    //cool down for the echolocation wave
    private IEnumerator EcholocationCoolDown()
    {
        echolocating = true;
        wave.SetActive(true);       //actives the wave sprite so the player know the direction the used echolocation in
        yield return new WaitForSeconds(2);
        wave.SetActive(false);
        echolocating = false;
    }

    //cool down for the movement
    private IEnumerator MovingCoolDown()
    {
        moving = true;
        rigidBody.AddForce(transform.up * moveForce, ForceMode2D.Impulse);     //moves the player
        yield return new WaitForSeconds(1);
        rigidBody.velocity = Vector2.zero;      //stops moving the player
        moving = false;
    }

    //connects to the arduino
    private void ConnectToSerial()
    {
        Debug.Log("Attempting Serial: " + commPort);

        // Read this: https://support.microsoft.com/en-us/help/115831/howto-specify-serial-ports-larger-than-com9
        serial = new SerialPort("\\\\.\\COM" + commPort, 9600);
        serial.ReadTimeout = 50;
        serial.Open();

    }

    //sends signals to the arduino
    private void WriteToArduino(string message)
    {
        serial.WriteLine(message);
        serial.BaseStream.Flush();
    }

    //takes values of the arduino into unity
    private string ReadFromArduino(int timeout = 0)
    {
        serial.ReadTimeout = timeout;
        try
        {
            return serial.ReadLine();
        }
        catch (TimeoutException e)
        {
            return null;
        }
    }

    //closes the serial when the player dies.
    private void OnDestroy()
    {
        Debug.Log("Exiting");
        serial.Close();
    }

    // https://forum.unity.com/threads/re-map-a-number-from-one-range-to-another.119437/
    float Remap(float value, float from1, float to1, float from2, float to2)
    {
        return (value - from1) / (to1 - from1) * (to2 - from2) + from2;
    }
}