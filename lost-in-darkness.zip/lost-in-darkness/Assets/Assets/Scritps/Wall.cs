﻿using UnityEngine;

public class Wall : MonoBehaviour
{
    [SerializeField] Arduino player;        //refrence to the player class

    //damages the player
    protected void DetectDamage()
    {
        //Send signal to player class script
        player.Damage();
    }

    //changes player's current state to echolcaotion mode so the player don't take more damage
    protected void PushAway()
    {
        if (player.movingState)        
        {
            player.ChangeState();
        }
    }

    //actives on collsion with another object
    private void OnCollisionEnter2D(Collision2D coll)
    {
        DetectDamage();
        PushAway();
    }
}